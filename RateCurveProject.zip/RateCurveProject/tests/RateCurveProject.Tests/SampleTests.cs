using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RateCurveProject.Tests
{
    [TestClass]
    public class SampleTests
    {
        [TestMethod]
        public void HelloWorldTest()
        {
            Assert.AreEqual(1 + 1, 2);
        }
    }
}